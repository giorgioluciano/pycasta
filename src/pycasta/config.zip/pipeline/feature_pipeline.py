import numpy as np
import logging

from scipy.spatial import KDTree

from .. import config
from ..features.occlusion_features import (
    compute_hybrid_occlusion_features,
    compute_hybrid_occlusion_features_v2,
)
from .models import PocketCandidate
from ..features.geometry_features import compute_geometry_features
from ..features.mouth_features import compute_mouth_features_for_all_pockets


def build_pocket_candidates(ranked_pockets, tetra_positions):
    candidates = []

    for idx, pocket in enumerate(ranked_pockets, start=1):
        pocket_points = tetra_positions[pocket].reshape(-1, 3)
        representative_point = np.mean(pocket_points, axis=0).tolist()

        candidates.append(
            PocketCandidate(
                pocket_id=idx,
                tetra_indices=list(pocket),
                representative_point=representative_point,
            )
        )

    return candidates


def enrich_with_geometry(candidates, tetra_positions):
    for candidate in candidates:
        feats = compute_geometry_features(tetra_positions, candidate.tetra_indices)
        candidate.volume = feats["volume"]
        candidate.depth = feats["depth"]
        candidate.features.update(feats)
    return candidates


def enrich_with_mouth(candidates, ranked_pockets, simplices, protein_coords, ligand_coords=None):
    mouth_data = compute_mouth_features_for_all_pockets(
        ranked_pockets=ranked_pockets,
        simplices=simplices,
        protein_coords=protein_coords,
        ligand_coords=ligand_coords,
    )

    for candidate, mouth in zip(candidates, mouth_data):
        candidate.mouth_area = mouth.get("mouth_area")
        candidate.mouth_perimeter = mouth.get("mouth_circumference")
        candidate.mouth_center = mouth.get("mouth_center")
        candidate.rim_atoms = mouth.get("rim_atoms", [])
        candidate.ligand_distance_to_mouth = mouth.get("ligand_distance")

        candidate.features.update(
            {
                "mouth_area": candidate.mouth_area,
                "mouth_perimeter": candidate.mouth_perimeter,
                "ligand_distance_to_mouth": candidate.ligand_distance_to_mouth,
                "rim_atom_count": len(candidate.rim_atoms),
            }
        )

    return candidates

def enrich_with_hybrid_occlusion(
    candidates,
    protein_coords,
    protein_atoms,
    atom_radii,
    sasa_by_residue=None,
):
    logging.info("ENTER enrich_with_hybrid_occlusion")

    if not config.USE_HYBRID_OCCLUSION:
        logging.info("Hybrid occlusion disabled by config")
        return candidates

    method = getattr(config, "HYBRID_OCCLUSION_METHOD", "baseline")
    kd_tree = KDTree(protein_coords)

    for candidate in candidates:
        pocket_id = getattr(candidate, "pocket_id", None)
        before_keys = list(candidate.features.keys()) if getattr(candidate, "features", None) else []

        logging.info(
            f"ENRICH_HYBRID pocket_id={pocket_id} method={method} before_keys={before_keys}"
        )

        if method == "v2":
            features = compute_hybrid_occlusion_features_v2(
                candidate=candidate,
                protein_coords=protein_coords,
                protein_atoms=protein_atoms,
                atom_radii=atom_radii,
                sasa_by_residue=sasa_by_residue,
                kd_tree=kd_tree,
            )
        else:
            features = compute_hybrid_occlusion_features(
                candidate=candidate,
                protein_coords=protein_coords,
                protein_atoms=protein_atoms,
                atom_radii=atom_radii,
                sasa_by_residue=sasa_by_residue,
                kd_tree=kd_tree,
            )

        if not features:
            logging.info(f"ENRICH_HYBRID pocket_id={pocket_id} features empty")
            continue

        clean_features = {k: v for k, v in features.items() if v is not None}

        logging.info(
            f"ENRICH_HYBRID pocket_id={pocket_id} new_keys={list(clean_features.keys())}"
        )

        candidate.features.update(clean_features)

        logging.info(
            f"ENRICH_HYBRID pocket_id={pocket_id} after_keys={list(candidate.features.keys())}"
        )

    return candidates