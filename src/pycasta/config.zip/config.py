from pathlib import Path

_current_alpha = None
_current_merge_threshold = None
_current_min_pocket_volume = None

PROJECT_ROOT = Path(r"C:\github\pycasta")
DATA_DIR = PROJECT_ROOT / "data"

OUTPUT_DIR = r"C:\github\pycasta\src\pycasta\results"
VERSION_TAG = "coach420_test"

BOUNDED_DIR = r"C:\github\pycasta\data\coach420\pdbs"
UNBOUNDED_DIR = None
DATASET_DIR = DATA_DIR
CORRESPONDENCE_FILE = None

INCLUDE_WATER = False
CONNECTIVITY_THRESHOLD = 1

USE_SASA = True
SASA_METHOD = "pymol"

USE_CGAL = False
WEIGHTED_DELAUNAY = False

FILTER_ALPHA_BY_SASA = False
SASA_THRESHOLD = 0

ATOM_SPLITTING = True
ATOM_SPLITTING_MODE = "CAST"
SIMPLE_SPLIT = False

CALCULATE_MOUTH_PARAMETERS = True
VOLUME_METHOD = "analytic"

LIGAND_CONTACT_METHOD = "sasa"
LIGAND_CONTACT_THRESHOLD = 4.0
LIGAND_THRESHOLD = 4.0
STRICT_DISTANCE_THRESHOLD = 4.0

SEMIAUTO_ALPHA = False
MANUAL_ALPHA = 2
ALPHA_PREFERENCE = None

SAVE_ALPHA = True
MIN_POCKET_VOLUME = 50
FILTER_AFTER_MERGE = True

FLOW_METHOD = "discrete_approx"
FLOW_KWARGS = {
    "max_steps": 100,
    "tol_fraction": 0.01,
    "sigma_p": 1.4,
    "adaptive": True,
    "adaptive_factor": 0.5,
    "base_step_size": 3,
    "min_steps": 3,
    "debug": True,
    "write_steps": True,
}

MERGE_CLUSTERS = True
MERGE_THRESHOLD = 18

USE_SASA_CONTACT_VALIDATION = False
SASA_CONTACT_THRESHOLD = 4.0

VALIDATION_METHOD = "mesh_extrusion"
FAKE_SPHERE_RADIUS = 50
MESH_EXTRUSION_DISTANCE = 4
SAVE_EXTRUDED_MESHES = True

NUM_POCKETS_TO_VALIDATE = 20
ALPHA_RANKING = 1
BETA_RANKING = 1
NUM_POCKETS_TO_SAVE = 5
USE_EXISTING_RESULTS = False
DEBUG = True

USE_HYBRID_OCCLUSION = False
HYBRID_OCCLUSION_METHOD = "baseline"
OCCLUSION_USE_SASA = True
OCCLUSION_NUM_RAYS = 96
OCCLUSION_MAX_DISTANCE = 12.0
OCCLUSION_NEIGHBOR_RADIUS = 16.0
OCCLUSION_LOW_SASA_THRESHOLD = 5.0
SAVE_OCCLUSION_DEBUG = True
SAVE_DEBUG_VIEWER = False
DEBUG_VIEWER_MAX_PROTEIN_POINTS = 4000

RANKING_METHOD = "percentile_log"

USE_GRAPH_FILTERED_ALPHA = False
ALPHA_MAX_EDGE_FACTOR = 2.5
ALPHA_LOCAL_SCALE_K = 6

SAVE_TRIANGULATION_DEBUG = True

def get_alpha():
    return MANUAL_ALPHA if _current_alpha is None else _current_alpha

def set_alpha(value):
    global _current_alpha
    _current_alpha = float(value)

def reset_alpha():
    global _current_alpha
    _current_alpha = None

def get_merge_threshold():
    return MERGE_THRESHOLD if _current_merge_threshold is None else _current_merge_threshold

def set_merge_threshold(value):
    global _current_merge_threshold
    _current_merge_threshold = float(value)

def reset_merge_threshold():
    global _current_merge_threshold
    _current_merge_threshold = None

def get_min_pocket_volume():
    return MIN_POCKET_VOLUME if _current_min_pocket_volume is None else _current_min_pocket_volume

def set_min_pocket_volume(value):
    global _current_min_pocket_volume
    _current_min_pocket_volume = float(value)

def reset_min_pocket_volume():
    global _current_min_pocket_volume
    _current_min_pocket_volume = None