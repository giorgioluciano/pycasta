# -*- coding: utf-8 -*-
"""
visualization/ao_calculator.py
Ambient Occlusion molecolare - numpy puro, modulare.
0=esposto  1=occluded/cavita
"""
import numpy as np
from scipy.spatial import KDTree

def compute_ao(coords,radii,N_rays=64,max_dist=8.0,seed=42):
    rng=np.random.default_rng(seed); N=len(coords)
    dirs=_sphere_dirs(N_rays,rng)
    centroid=coords.mean(axis=0)
    tree=KDTree(coords); ao=np.zeros(N)
    idxs_list=tree.query_ball_point(coords,r=max_dist)
    for i in range(N):
        pos_i=coords[i]
        outward=pos_i-centroid; norm_o=np.linalg.norm(outward)
        outward=outward/norm_o if norm_o>1e-6 else np.array([0.,0.,1.])
        hemi=dirs.copy(); hemi[dirs@outward<0]*=-1
        nb=[j for j in idxs_list[i] if j!=i]
        if not nb: continue
        nb_c=coords[nb]; nb_r=radii[nb]; blocked=0
        for ray in hemi:
            delta=nb_c-pos_i; t=delta@ray; mask=t>0
            if not mask.any(): continue
            proj=delta[mask]-t[mask,None]*ray
            if np.any(np.linalg.norm(proj,axis=1)<nb_r[mask]*0.85): blocked+=1
        ao[i]=blocked/N_rays
    return ao

def _sphere_dirs(n,rng):
    d=rng.standard_normal((n*2,3)); norms=np.linalg.norm(d,axis=1,keepdims=True)
    return (d/(norms+1e-12))[:n]

def ao_to_color(ao,cmap_name="coolwarm_r"):
    import matplotlib.pyplot as plt
    return plt.get_cmap(cmap_name)(ao)[:,:3].astype(np.float32)
